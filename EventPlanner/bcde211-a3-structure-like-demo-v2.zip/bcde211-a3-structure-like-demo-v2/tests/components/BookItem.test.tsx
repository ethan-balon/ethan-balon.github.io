import { render, screen } from '@testing-library/react'
import '@testing-library/jest-dom'
import { BookItem } from '../../src/components/BookItem'
import type { BookViewModel } from '../../src/types/book_types'
import userEvent from '@testing-library/user-event'

describe('BookItem', () => {
  const mockBook: BookViewModel = {
    id: 1,
    title: 'Clean Code',
    author: 'Robert C. Martin',
    completed: false,
  }

  const user = userEvent.setup()

  test('renders book title, author and status correctly', () => {
    render(
      <BookItem
        book={mockBook}
        onToggle={async () => {}}
        onRemove={async () => {}}
      />,
    )

    expect(screen.getByText(/Clean Code/)).toBeInTheDocument()
    expect(screen.getByText(/Robert C\. Martin/)).toBeInTheDocument()
    expect(screen.getByText(/Pending/)).toBeInTheDocument()
  })

  test('shows Done when book is completed', () => {
    const doneBook: BookViewModel = {
      ...mockBook,
      completed: true,
    }

    render(
      <BookItem
        book={doneBook}
        onToggle={async () => {}}
        onRemove={async () => {}}
      />,
    )

    expect(screen.getByText(/Done/)).toBeInTheDocument()
  })

  test('calls onToggle with correct id when Toggle button is clicked', async () => {
    const toggleMock = jest.fn().mockResolvedValue(undefined)

    render(
      <BookItem
        book={mockBook}
        onToggle={toggleMock}
        onRemove={async () => {}}
      />,
    )

    await user.click(screen.getByRole('button', { name: /toggle/i }))

    expect(toggleMock).toHaveBeenCalledTimes(1)
    expect(toggleMock).toHaveBeenCalledWith(1)
  })

  test('calls onRemove with correct id when Delete button is clicked', async () => {
    const removeMock = jest.fn().mockResolvedValue(undefined)

    render(
      <BookItem
        book={mockBook}
        onToggle={async () => {}}
        onRemove={removeMock}
      />,
    )

    await user.click(screen.getByText('Delete'))

    expect(removeMock).toHaveBeenCalledTimes(1)
    expect(removeMock).toHaveBeenCalledWith(1)
  })
})
