describe('ReadingListManager', () => {
  test('placeholder test', () => {
    expect(true).toBe(true)
  })
})
