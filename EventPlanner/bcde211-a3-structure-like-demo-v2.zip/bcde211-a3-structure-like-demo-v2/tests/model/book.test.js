import { Book } from '../../src/model/book.js'

describe('Book', () => {
  test('creates a book correctly', () => {
    const book = new Book(1, 'Clean Code', 'Robert C. Martin')

    expect(book.title).toBe('Clean Code')
    expect(book.author).toBe('Robert C. Martin')
    expect(book.completed).toBe(false)
  })
})
