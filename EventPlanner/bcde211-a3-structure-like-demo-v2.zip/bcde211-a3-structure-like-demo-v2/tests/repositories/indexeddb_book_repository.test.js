import { IndexedDbBookRepository } from '../../src/repositories/indexeddb_book_repository.js'

describe('IndexedDbBookRepository', () => {
  let repo

  beforeEach(async () => {
    repo = new IndexedDbBookRepository('test-db')
    await repo.clear()
  })

  test('adds a book and returns generated id', async () => {
    const book = {
      title: 'Clean Code',
      author: 'Robert C. Martin',
    }

    const id = await repo.add(book)

    expect(typeof id).toBe('number')
  })

  test('retrieves a book by id', async () => {
    const book = {
      title: 'Refactoring',
      author: 'Martin Fowler',
    }

    const id = await repo.add(book)

    const result = await repo.getById(id)

    expect(result).toMatchObject({
      id,
      title: 'Refactoring',
      author: 'Martin Fowler',
      completed: false,
    })
  })

  test('returns all books', async () => {
    await repo.add({ title: 'Book 1', author: 'A' })
    await repo.add({ title: 'Book 2', author: 'B' })

    const all = await repo.getAll()

    expect(all).toHaveLength(2)
  })

  test('updates a book', async () => {
    const id = await repo.add({
      title: 'Original',
      author: 'Author',
    })

    await repo.update({
      id,
      title: 'Updated',
      author: 'Author',
      completed: true,
    })

    const updated = await repo.getById(id)

    expect(updated.title).toBe('Updated')
    expect(updated.completed).toBe(true)
  })

  test('removes a book', async () => {
    const id = await repo.add({
      title: 'To Remove',
      author: 'X',
    })

    await repo.remove(id)

    const result = await repo.getById(id)

    expect(result).toBeUndefined()
  })
})
