import React from 'react'
import ReactDOM from 'react-dom/client'

import App from './App'

import { ReadingListManager } from './model/reading_list_manager.js'
import { IndexedDbBookRepository } from './repositories/indexeddb_book_repository.js'

import { registerServiceWorker } from './pwa/register_service_worker.js'

const readingListManager = new ReadingListManager(new IndexedDbBookRepository())

registerServiceWorker()

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App readingListManager={readingListManager} />
  </React.StrictMode>,
)
