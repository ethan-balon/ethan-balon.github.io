import { BookRepositoryContract } from './book_repository_contract.js'

export class IndexedDbBookRepository extends BookRepositoryContract {
  #dbName
  #storeName = 'books'

  constructor(dbName = 'reading-list-db') {
    super()
    this.#dbName = dbName
  }

  async #open() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.#dbName, 1)

      request.onupgradeneeded = (event) => {
        const db = event.target.result

        if (!db.objectStoreNames.contains(this.#storeName)) {
          db.createObjectStore(this.#storeName, {
            keyPath: 'id',
            autoIncrement: true,
          })
        }
      }

      request.onsuccess = () => resolve(request.result)
      request.onerror = () => reject(request.error)
    })
  }

  async add(bookRecord) {
    const db = await this.#open()

    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.#storeName, 'readwrite')
      const store = tx.objectStore(this.#storeName)

      const recordToInsert = {
        title: bookRecord.title,
        author: bookRecord.author,
        completed: bookRecord.completed ?? false,
      }

      const req = store.add(recordToInsert)

      req.onsuccess = () => resolve(req.result)
      req.onerror = () => reject(req.error)
    })
  }

  async getById(id) {
    const db = await this.#open()

    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.#storeName, 'readonly')
      const store = tx.objectStore(this.#storeName)

      const req = store.get(id)

      req.onsuccess = () => resolve(req.result)
      req.onerror = () => reject(req.error)
    })
  }

  async getAll() {
    const db = await this.#open()

    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.#storeName, 'readonly')
      const store = tx.objectStore(this.#storeName)

      const req = store.getAll()

      req.onsuccess = () => resolve(req.result)
      req.onerror = () => reject(req.error)
    })
  }

  async update(bookRecord) {
    const db = await this.#open()

    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.#storeName, 'readwrite')
      const store = tx.objectStore(this.#storeName)

      if (bookRecord.id === undefined || bookRecord.id === null) {
        reject(new Error('Cannot update book without id'))
        return
      }

      const recordToUpdate = {
        id: bookRecord.id,
        title: bookRecord.title,
        author: bookRecord.author,
        completed: bookRecord.completed ?? false,
      }

      const req = store.put(recordToUpdate)

      req.onsuccess = () => resolve()
      req.onerror = () => reject(req.error)
    })
  }

  async remove(id) {
    const db = await this.#open()

    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.#storeName, 'readwrite')
      const store = tx.objectStore(this.#storeName)

      const req = store.delete(id)

      req.onsuccess = () => resolve()
      req.onerror = () => reject(req.error)
    })
  }

  async clear() {
    const db = await this.#open()

    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.#storeName, 'readwrite')
      const store = tx.objectStore(this.#storeName)

      const req = store.clear()

      req.onsuccess = () => resolve()
      req.onerror = () => reject(req.error)
    })
  }
}
