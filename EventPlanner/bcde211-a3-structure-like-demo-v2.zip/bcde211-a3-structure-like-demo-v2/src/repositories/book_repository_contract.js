export class BookRepositoryContract {
  /**
   * Add a plain book record to persistence.
   *
   * Expected input:
   * {
   *   title: string,
   *   author: string,
   *   completed?: boolean
   * }
   *
   * Expected return:
   * generated numeric id
   */
  async add(bookRecord) {
    throw new Error('Not implemented')
  }

  /**
   * Find one plain book record by id.
   *
   * Expected return:
   * {
   *   id: number,
   *   title: string,
   *   author: string,
   *   completed: boolean
   * }
   *
   * or undefined if no record exists.
   */
  async getById(id) {
    throw new Error('Not implemented')
  }

  /**
   * Return all plain book records.
   */
  async getAll() {
    throw new Error('Not implemented')
  }

  /**
   * Update an existing plain book record.
   *
   * Expected input:
   * {
   *   id: number,
   *   title: string,
   *   author: string,
   *   completed: boolean
   * }
   */
  async update(bookRecord) {
    throw new Error('Not implemented')
  }

  /**
   * Remove one record by id.
   */
  async remove(id) {
    throw new Error('Not implemented')
  }

  /**
   * Remove all records.
   */
  async clear() {
    throw new Error('Not implemented')
  }
}
