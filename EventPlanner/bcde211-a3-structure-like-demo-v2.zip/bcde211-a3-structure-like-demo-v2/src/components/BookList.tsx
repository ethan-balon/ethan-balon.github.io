import { BookItem } from './BookItem'
import type { BookViewModel } from '../types/book_types'

interface Props {
  books: BookViewModel[]
  onToggle: (id: number) => Promise<void>
  onRemove: (id: number) => Promise<void>
}

export function BookList({ books, onToggle, onRemove }: Props) {
  return (
    <ul>
      {books.map((b) => (
        <BookItem key={b.id} book={b} onToggle={onToggle} onRemove={onRemove} />
      ))}
    </ul>
  )
}
