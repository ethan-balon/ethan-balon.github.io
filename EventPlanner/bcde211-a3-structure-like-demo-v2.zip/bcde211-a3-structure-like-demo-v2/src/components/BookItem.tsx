import type { BookViewModel } from '../types/book_types'
import type { JSX } from 'react/jsx-runtime'

interface Props {
  book: BookViewModel
  onToggle: (id: number) => Promise<void>
  onRemove: (id: number) => Promise<void>
}

export function BookItem({ book, onToggle, onRemove }: Props): JSX.Element {
  return (
    <li>
      {book.title} by {book.author} - {book.completed ? 'Done' : 'Pending'}
      <button onClick={() => onToggle(book.id)}>Toggle</button>
      <button onClick={() => onRemove(book.id)}>Delete</button>
    </li>
  )
}
