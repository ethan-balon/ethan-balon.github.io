import { useState } from 'react'
import type { JSX } from 'react/jsx-runtime'

interface Props {
  onAddBook: (title: string, author: string) => Promise<void>
}

export function BookForm({ onAddBook }: Props): JSX.Element {
  const [title, setTitle] = useState<string>('')
  const [author, setAuthor] = useState<string>('')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (!title || !author) return

    await onAddBook(title, author)

    setTitle('')
    setAuthor('')
  }

  return (
    <form onSubmit={handleSubmit}>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Title"
      />
      <input
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
        placeholder="Author"
      />
      <button>Add</button>
    </form>
  )
}
