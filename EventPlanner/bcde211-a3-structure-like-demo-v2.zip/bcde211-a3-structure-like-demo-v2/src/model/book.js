export class Book {
  #id
  #title
  #author
  #completed

  constructor(id, title, author, completed = false) {
    this.#id = id
    this.#title = title
    this.#author = author
    this.#completed = completed
  }

  get id() {
    return this.#id
  }

  set id(value) {
    this.#id = value
  }

  get title() {
    return this.#title
  }

  get author() {
    return this.#author
  }

  get completed() {
    return this.#completed
  }

  toggleCompleted() {
    this.#completed = !this.#completed
  }

  toPlainObject() {
    return {
      id: this.#id,
      title: this.#title,
      author: this.#author,
      completed: this.#completed,
    }
  }

  static fromPlainObject(row) {
    return new Book(row.id, row.title, row.author, row.completed)
  }
}
