import { Book } from './book.js'

export class ReadingListManager {
  #repository
  #books
  #loaded

  constructor(repository) {
    this.#repository = repository
    this.#books = []
    this.#loaded = false
  }

  async add(title, author) {
    const book = new Book(null, title, author)

    const id = await this.#repository.add(book.toPlainObject())

    book.id = id

    this.#books.push(book)
    this.#loaded = true

    return book
  }

  async getAll() {
    if (!this.#loaded) {
      await this.loadAll()
    }

    return [...this.#books]
  }

  async loadAll() {
    const rows = await this.#repository.getAll()

    this.#books = rows.map((row) => Book.fromPlainObject(row))
    this.#loaded = true

    return [...this.#books]
  }

  async toggleCompleted(id) {
    if (!this.#loaded) {
      await this.loadAll()
    }

    const book = this.#books.find((b) => b.id === id)

    if (!book) {
      throw new Error('Book not found')
    }

    book.toggleCompleted()

    await this.#repository.update(book.toPlainObject())

    return book
  }

  async remove(id) {
    await this.#repository.remove(id)

    this.#books = this.#books.filter((b) => b.id !== id)
    this.#loaded = true
  }
}
