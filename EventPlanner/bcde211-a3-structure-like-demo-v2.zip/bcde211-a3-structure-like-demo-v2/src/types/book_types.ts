export interface BookViewModel {
  id: number
  title: string
  author: string
  completed: boolean
}
