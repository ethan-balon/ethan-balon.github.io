import type { BookViewModel } from './book_types'

export interface ReadingListService {
  getAll(): Promise<BookViewModel[]>
  add(title: string, author: string): Promise<BookViewModel>
  toggleCompleted(id: number): Promise<void>
  remove(id: number): Promise<void>
}
