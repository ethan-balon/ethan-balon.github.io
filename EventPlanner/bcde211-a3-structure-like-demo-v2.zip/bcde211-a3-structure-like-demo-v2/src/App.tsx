import './App.css'
import { useEffect, useState } from 'react'

import { BookForm } from './components/BookForm'
import { BookList } from './components/BookList'
import { OfflineBanner } from './components/OfflineBanner'

import type { BookViewModel } from './types/book_types'
import type { ReadingListService } from './types/reading_list_service'

interface BookModelLike {
  id: number
  title: string
  author: string
  completed: boolean
}

interface Props {
  readingListManager: ReadingListService
}

export default function App({ readingListManager }: Props) {
  const [books, setBooks] = useState<BookViewModel[]>([])

  useEffect(() => {
    async function loadBooks() {
      const loaded = await readingListManager.getAll()
      setBooks(loaded.map(toViewModel))
    }

    loadBooks()
  }, [readingListManager])

  async function addBook(title: string, author: string): Promise<void> {
    const created = await readingListManager.add(title, author)

    setBooks((prev) => [...prev, toViewModel(created)])
  }

  async function toggle(id: number): Promise<void> {
    await readingListManager.toggleCompleted(id)

    setBooks((prev) =>
      prev.map((book) =>
        book.id === id ? { ...book, completed: !book.completed } : book,
      ),
    )
  }

  async function remove(id: number): Promise<void> {
    await readingListManager.remove(id)

    setBooks((prev) => prev.filter((book) => book.id !== id))
  }

  return (
    <>
      <OfflineBanner />

      <main>
        <h1>Reading List</h1>

        <BookForm onAddBook={addBook} />

        <BookList books={books} onToggle={toggle} onRemove={remove} />
      </main>
    </>
  )
}

function toViewModel(book: BookModelLike): BookViewModel {
  return {
    id: book.id,
    title: book.title,
    author: book.author,
    completed: book.completed,
  }
}
